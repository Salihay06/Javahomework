public class Warrior {
    protected String name;
    protected int health;
    protected int baseDamage;

    public Warrior(String name, int health, int baseDamage) {
        this.name = name;
        this.health = health;
        this.baseDamage = baseDamage;
    }

    public void showInfo() {
        System.out.println("Warrior: " + name + " -- Health: " + health + " -- Base Damage: " + baseDamage);
    }

    public int attack(int targetDefense) {
        return baseDamage - targetDefense;
    }
}

