public class Knight extends Warrior {
    private String name; // Member hiding
    private int armorPower;

    public Knight(String name, int health, int baseDamage, int armorPower) {
        super(name, health, baseDamage);
        this.name = name;
        this.armorPower = armorPower;
    }

    @Override
    public void showInfo() {
        System.out.println("Knight: " + name + " -- Health: " + health + " -- Base Damage: " + baseDamage + " -- Armor Power: " + armorPower);
    }

    @Override
    public int attack(int targetDefense) {
        int damage = (int)(baseDamage + armorPower * 0.2) - targetDefense;
        return damage;
    }
}

