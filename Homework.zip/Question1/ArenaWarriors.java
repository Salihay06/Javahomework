import java.util.Scanner;

public class ArenaWarriors {
    public static void main(String[] args) {
        // Create one object from each subclass
        Knight knight = new Knight("Sir Lancelot", 150, 30, 25);
        Mage mage = new Mage("Gandalf", 100, 25, 50);
        Archer archer = new Archer("Legolas", 120, 35, 30);

        // Display information for each warrior
        knight.showInfo();
        mage.showInfo();
        archer.showInfo();

        // Prompt user for target defense value
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter the target's defense value: ");
        String input = scanner.nextLine();
        scanner.close();

        int targetDefense = 0;

        try {
            // Parse input to integer
            targetDefense = Integer.parseInt(input);

            // Check for negative value
            if (targetDefense < 0) {
                throw new IllegalArgumentException("Defense value cannot be negative!");
            }

            // Check if defense value is greater than 100
            if (targetDefense > 100) {
                throw new RuntimeException("Such a high defense value is not allowed!");
            }

            // Attack with each warrior and display damage
            System.out.println("\n--- Attack Results ---");
            int knightDamage = knight.attack(targetDefense);
            System.out.println("Knight damage: " + knightDamage);

            int mageDamage = mage.attack(targetDefense);
            System.out.println("Mage damage: " + mageDamage);

            int archerDamage = archer.attack(targetDefense);
            System.out.println("Archer damage: " + archerDamage);

        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid input! Please enter a numeric value.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

