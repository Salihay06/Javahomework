import java.util.Random;

public class Archer extends Warrior {
    private int criticalChance;

    public Archer(String name, int health, int baseDamage, int criticalChance) {
        super(name, health, baseDamage);
        this.criticalChance = criticalChance;
    }

    @Override
    public void showInfo() {
        System.out.println("Archer: " + name + " -- Health: " + health + " -- Base Damage: " + baseDamage + " -- Critical Chance: " + criticalChance + "%");
    }

    @Override
    public int attack(int targetDefense) {
        Random random = new Random();
        int baseAttack = baseDamage - targetDefense;
        
        // Check for critical hit
        int randomValue = random.nextInt(100);
        if (randomValue < criticalChance) {
            // Critical hit - damage doubled
            return baseAttack * 2;
        }
        
        return baseAttack;
    }
}

