import java.util.ArrayList;

public class MatrixMultiplication {

    static int SIZE = 50;

    public static void main(String[] args) {

        String studentID = "2311504208"; 

        ArrayList<Integer> oddDigits = new ArrayList<>();
        ArrayList<Integer> evenDigits = new ArrayList<>();

        
        for (char c : studentID.toCharArray()) {
            int digit = Character.getNumericValue(c);

            if (digit % 2 == 0) {
                evenDigits.add(digit);
            } else {
                oddDigits.add(digit);
            }
        }

        if (oddDigits.size() == 0 || evenDigits.size() == 0) {
            throw new RuntimeException("Student ID must contain both odd and even digits.");
        }

        int[][] matrix1 = new int[SIZE][SIZE];
        int[][] matrix2 = new int[SIZE][SIZE];
        int[][] result = new int[SIZE][SIZE];

       
        int index = 0;
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                matrix1[i][j] = oddDigits.get(index % oddDigits.size());
                index++;
            }
        }

        
        index = 0;
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                matrix2[i][j] = evenDigits.get(index % evenDigits.size());
                index++;
            }
        }

        ArrayList<Thread> threads = new ArrayList<>();

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {

                final int row = i;
                final int col = j;

                Thread t = new Thread(() -> {
                    try {
                        int sum = 0;
                        for (int k = 0; k < SIZE; k++) {
                            sum += matrix1[row][k] * matrix2[k][col];
                        }
                        result[row][col] = sum;
                    } catch (Exception e) {
                        throw new RuntimeException("Error during matrix multiplication.");
                    }
                });

                threads.add(t);
                t.start();
            }
        }

        
        for (Thread t : threads) {
            try {
                t.join();
            } catch (Exception e) {
                throw new RuntimeException("Thread error occurred.");
            }
        }

        
        System.out.println("\nFirst Matrix (10x10):");
        printMatrix(matrix1);

        System.out.println("\nSecond Matrix (10x10):");
        printMatrix(matrix2);

        System.out.println("\nResult Matrix (10x10):");
        printMatrix(result);
    }

    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
